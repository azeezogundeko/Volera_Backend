searched_results = [
    {
        "content": "# Product Information\n\n                ## Features\n                - **Name:** Star Wars Mouse Pad Large Pad To Mouse Notbook Computer Mousepad Cheapest  Gaming Padmouse Gamer To Laptop 80x40cm Mouse Mat  FADY\n                - **Description:** No description available\n                - **Brand:** Generic\n                - **Categories:**\n- Computing\n- Computer Accessories\n- Keyboards, Mice & Accessories\n- Mice\n                - **Key Features:**\n- Package:Yes\n- Style:Radiation Protection\n- Size:XL\n- Material:Rubber\n- Products Status:Stock\n- Model Number:Size 800x400x2mm\n                - **Box Contents:**\n- SKU: GE779EA5CTZAWNAFAMZ\n- Model: Fangyang\n- Size (L x W x H cm): 1*1*1\n- Weight (kg): 0.5\n- Color: Multi\n- Main Material: PVC\n                ",
        "metadata": {
            "title": "Star Wars Mouse Pad Large Pad To Mouse Notbook Computer Mousepad Cheapest  Gaming Padmouse Gamer To Laptop 80x40cm Mouse Mat  FADY",
            "price": 78584.0,
            "discount": 0.4,
            "product_url": "https://www.jumia.com.ng//generic-star-wars-mouse-pad-large-pad-to-mouse-notbook-computer-mousepad-cheapest-gaming-padmouse-gamer-to-laptop-80x40cm-mouse-mat-fady-384058832.html",
            "image_url": "https://ng.jumia.is/unsafe/fit-in/300x300/filters:fill(white)/product/23/8850483/1.jpg?2573"
        }
    },
    {
        "content": "# Product Information\n\n                ## Features\n                - **Name:** Falloutd Mousepad Gamer 900x400X3MM Gaming Mouse Pad Large Cheapest Notebook Pc Accessories Laptop Padmouse Ergonomic Mat\n                - **Description:** No description available\n                - **Brand:** Generic\n                - **Categories:**\n- Computing\n- Computer Accessories\n- Keyboards, Mice & Accessories\n- Mice\n                - **Key Features:**\n\n                - **Box Contents:**\n- SKU: GE779EA625YBKNAFAMZ\n- Product Line: Generic\n- Model: Fangyang\n- Production Country: China\n- Size (L x W x H cm): 1*1*1\n- Weight (kg): 0.5\n- Color: Multi\n- Main Material: PVC\n                ",
        "metadata": {
            "title": "Falloutd Mousepad Gamer 900x400X3MM Gaming Mouse Pad Large Cheapest Notebook Pc Accessories Laptop Padmouse Ergonomic Mat",
            "price": 34676.0,
            "discount": 0.39,
            "product_url": "https://www.jumia.com.ng//generic-falloutd-mousepad-gamer-900x400x3mm-gaming-mouse-pad-large-cheapest-notebook-pc-accessories-laptop-padmouse-ergonomic-mat-384043466.html",
            "image_url": "https://ng.jumia.is/unsafe/fit-in/300x300/filters:fill(white)/product/66/4340483/1.jpg?0753"
        }
    },
    {
        "content": "# Product Information\n\n                ## Features\n                - **Name:** Gaming Mouse Pad Wrist Protection Gamer Cabinet Mat Laptops Anime Cheapest Stuff Computer Mousepad Mause Pc Green\n                - **Description:** No description available\n                - **Brand:** Generic\n                - **Categories:**\n- Computing\n- Computer Accessories\n- Keyboards, Mice & Accessories\n- Keyboard & Mice Accessories\n- Mouse Pads\n                - **Key Features:**\n- Material:memory cotton\n- Origin:Mainland China\n- Products Status:STOCK\n- Style:non-slip\n- Model Number:Gaming Mouse Pad\n- Package:Yes\n- Size:L(900mm)xW(400mm) xH (2mm)\n- Thickness:2mm\n- DropShipping:Cainiao worry-free standard\n- Product Function:Rubber non-slip\n- Product Usage Scenarios:mat for keyboard\n- Feature 1:desk mat largegaming mousepad\n- Feature 2:gabinete gamermouse pad xxl\n- Feature 3:mouse pad xxl\n                - **Box Contents:**\n- SKU: GE779EA627JC3NAFAMZ\n- Model: HuiKeshubiaodian1818\n- Production Country: China\n- Size (L x W x H cm): 10x8x6\n- Weight (kg): 0.1\n- Color: Green\n- Main Material: PVC\n                ",
        "metadata": {
            "title": "Gaming Mouse Pad Wrist Protection Gamer Cabinet Mat Laptops Anime Cheapest Stuff Computer Mousepad Mause Pc Green",
            "price": 53899.0,
            "discount": 0.42,
            "product_url": "https://www.jumia.com.ng//generic-gaming-mouse-pad-wrist-protection-gamer-cabinet-mat-laptops-anime-cheapest-stuff-computer-mousepad-mause-pc-green-393970566.html",
            "image_url": "https://ng.jumia.is/unsafe/fit-in/300x300/filters:fill(white)/product/66/5079393/1.jpg?7094"
        }
    },
    {
        "content": "# Product Information\n\n                ## Features\n                - **Name:** Gaming Mouse Pad Wrist Protection Gamer Cabinet Mat Laptops Anime Cheapest Stuff Computer Mousepad Mause Pc RubberBlack\n                - **Description:** No description available\n                - **Brand:** Generic\n                - **Categories:**\n- Computing\n- Computer Accessories\n- Keyboards, Mice & Accessories\n- Keyboard & Mice Accessories\n- Mouse Pads\n                - **Key Features:**\n- Material:memory cotton\n- Origin:Mainland China\n- Products Status:STOCK\n- Style:non-slip\n- Model Number:Gaming Mouse Pad\n- Package:Yes\n- Size:L(900mm)xW(400mm) xH (2mm)\n- Thickness:2mm\n- DropShipping:Cainiao worry-free standard\n- Product Function:Rubber non-slip\n- Product Usage Scenarios:mat for keyboard\n- Feature 1:desk mat largegaming mousepad\n- Feature 2:gabinete gamermouse pad xxl\n- Feature 3:mouse pad xxl\n                - **Box Contents:**\n- SKU: GE779EA6GUHB1NAFAMZ\n- Model: HuiKeshubiaodian1822\n- Production Country: China\n- Size (L x W x H cm): 10x8x6\n- Weight (kg): 0.1\n- Color: Rubber-Black\n- Main Material: PVC\n                ",
        "metadata": {
            "title": "Gaming Mouse Pad Wrist Protection Gamer Cabinet Mat Laptops Anime Cheapest Stuff Computer Mousepad Mause Pc RubberBlack",
            "price": 27432.0,
            "discount": 0.42,
            "product_url": "https://www.jumia.com.ng//generic-gaming-mouse-pad-wrist-protection-gamer-cabinet-mat-laptops-anime-cheapest-stuff-computer-mousepad-mause-pc-rubberblack-312039019.html",
            "image_url": "https://ng.jumia.is/unsafe/fit-in/300x300/filters:fill(white)/product/91/0930213/1.jpg?0068"
        }
    }
]

from agents import State, agent_manager, comparison_agent_node
from schema import WSMessage
# 'Find the cheapest laptop available on the market.  Consider all major retailers and brands.', 'Provide the name of the laptop, its price, and where it can be purchased.', 'If multiple laptops share the same lowest price, list them all. '
request = WSMessage(
    user_id="user_id",
    focus_mode=agent_manager.comparison_mode,
    files=["file1", "file2"],
    message={
        "content": "What is the cheapest laptop?"
    },
    history=[],
    optimization_mode="fast",
    
)
state = State(
    ws_message=[request],
    agent_results={
        agent_manager.scrape_mode: searched_results,
        agent_manager.meta_agent: {
            "next_node": agent_manager.comparison_agent,
            "instructions": "Find the cheapest laptop available on the market.  Consider all major retailers and brands."
        }
    },
    final_result={},
    chat_limit=10,
    chat_finished=False,
    previous_node="",
    previous_search_queries=[],
    message_history=[]
)


async def test_search_agent_node():
    result = await comparison_agent_node(state)


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_search_agent_node())


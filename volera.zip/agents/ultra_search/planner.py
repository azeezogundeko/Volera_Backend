import asyncio
from typing import Literal

from ..legacy.base import BaseAgent
from ..planner_agent import PlannerAgent
from .prompt import planner_system_prompt
from ..config import agent_manager
from ..state import State
from .schema import PlannerSchema
from schema import extract_agent_results
# from utils.memory import store
from ..memory import mem_agent
from ..tools.schema import extract_dataclass_messages

from utils.logging import logger

from pydantic_ai.result import ResultDataT
from langgraph.types import Command
from langgraph.store.base import BaseStore
from appwrite.id import ID


class PlannerAgent(BaseAgent):
    def __init__(self, *args, **kwargs):
        super().__init__(
            name=agent_manager.planner_agent,
            model='google-gla:gemini-2.0-flash-exp', 
            system_prompt=planner_system_prompt, 
            result_type=PlannerSchema, **kwargs)


    @extract_agent_results(agent_manager.planner_agent)
    async def run(self, state: State, config, store: BaseStore) -> ResultDataT:
        user_input = state["human_response"] if "human_response" in state else None
        if user_input is None:
            user_input = state['ws_message']['content']

        research_agent_result = state["agent_results"].get(agent_manager.research_agent, None)

        previous_search_queries = []
        if research_agent_result is not None:
            previous_search_queries = research_agent_result['searched_queries']

        
        # search memeory

        memory = store.search(
            state["namespace"],
            query=user_input,
            limit=3
        )
        print(memory)

            
        user_prompt = {
            "USER_INPUT": user_input,
            "PREVIOUS_SEARCH_QUERIES": previous_search_queries,
            "PAST CONVERSATION SUMMARIES": memory
        }

        user_id = state['user_id']
        previous_messages = state.get("message_history", [])

        model_to_use = state['model']
        model_config = self.get_model_config(model_to_use)

        response = await asyncio.wait_for(
            self.call_llm(
                user_id=user_id,
                user_prompt=str(user_prompt),
                type='text',
                message_history=previous_messages,
                model=model_config['model'],
                deps=model_config['deps']
                ),
            timeout=60
            )
        logger.info("Planner agent executed successfully.")

        state["message_history"] = previous_messages + response.new_messages()
        return response
    
    async def __call__(self, state: State, config: dict = {}, *, store: BaseStore)-> Command[
        Literal[agent_manager.research_agent, agent_manager.human_node]]:

        response = await self.run(state, config, store)
        data = response.data

        if "user" in data.action:
            logger.info("Routing to Human Node")
            return await self.go_to_user_node(state, ai_response=data.content, go_back_to_node=agent_manager.planner_agent)

        await self.websocket_manager.send_progress(state['ws_id'], status="comment", comment=data.comment)
        logger.info("Routing to Research Agent")
        return Command(goto=agent_manager.research_agent, update=state)
        

planner_agent = PlannerAgent()
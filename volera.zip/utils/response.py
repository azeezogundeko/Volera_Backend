from fastapi.responses import JSONResponse

class VoleraResponse(JSONResponse):
    ...
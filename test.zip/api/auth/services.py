import random
import asyncio
from typing import Any, Optional
from datetime import datetime, timedelta, timezone
import hashlib

from db import user_db
from .model import UserProfile, UserPreferences

from config import ACCESS_TOKEN_EXPIRE_MINUTES, ALGORITHM, SECRET_KEY
from .schema import UserIn, TokenData, UserOut
from .schema_in import ProfileSchema, UserCreate

from api.admin.services import system_log
from .model import Referral, UserCredits
from .email import send_formal_welcome_email

from utils.emails import send_new_user_email
from utils.logging import logger


from jose import JWTError, jwt
from appwrite.input_file import InputFile
from appwrite.client import AppwriteException
from passlib.context import CryptContext
from fastapi import Depends, HTTPException, BackgroundTasks
from fastapi.requests import Request
from fastapi.security import OAuth2PasswordBearer
from appwrite.query import Query
from utils.limiter import Limiter



pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# Initialize rate limiter for email-based attempts
email_limiter = Limiter()

def hash_email(email: str) -> str:
    # Generate a SHA-256 hash and truncate it to 36 characters
    hashed = hashlib.sha256(email.encode()).hexdigest()
    return hashed[:36]

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def split_name(full_name: str):
    # Try splitting by underscore
    if '_' in full_name:
        parts = full_name.split('_')
        return parts[0], parts[-1]
    
    # Try splitting by space
    parts = full_name.split()
    if len(parts) > 1:
        return parts[0], parts[-1]
    
    # If no clear split, use the full name as first name
    return full_name, ''



def generate_random_six_digit_number():
    return random.randint(100000, 999999)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict:
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])

async def get_user_by_email(email: str):
    try:
        kwgs = dict(
            queries = [Query.equal('email', email)]
        )

        users: str | Any | bytes | None = await asyncio.to_thread(user_db.list, **kwgs)
        user = users["users"][0]
        return UserIn(**user)
    except Exception as e:
        print(e)
        return None

async def get_user(email: str) -> Optional[UserIn]:
    try:
        user_id = hash_email(email)
        user = await asyncio.to_thread(user_db.get, user_id)
        
        return UserIn(**user)
    except AppwriteException:
        return None

async def get_user_by_id(user_id) -> Optional[UserIn]:
    try:
        user = await asyncio.to_thread(user_db.get, user_id)
        return UserIn(**user)
    except Exception:
        return None
    

async def get_email_client_id(request: Request, email: str, *args, **kwargs) -> str:
    """Generate a rate limit key for email-based limiting."""
    return f"email:{email}"

@email_limiter.limit(times=3, minutes=30, key_func=get_email_client_id)  # 3 attempts per 30 minutes per email
async def authenticate_user(request: Request, email: str, password: str) -> Optional[UserIn]:
    """
    Authenticate user with rate limiting per email address.
    Rate limits:
    - 3 attempts per 30 minutes per email address
    This helps prevent brute force attacks on specific accounts.
    """
    user = await get_user_by_email(email)
    print(user)
    if not user or not verify_password(password, user.password):
        # Log failed attempt
        logger.warning(f"Failed login attempt for email: {email}")
        return None
    return user


# Dependency to get current user
async def get_current_user(token: str = Depends(oauth2_scheme)) -> UserIn:
    try:
        payload = decode_access_token(token)
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        token_data = TokenData(email=email)
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await get_user_by_email(token_data.email)
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return user


async def create_new_user(payload: UserCreate, background_tasks: BackgroundTasks):
    user = await get_user_by_email(payload.email)
    if user:
        raise HTTPException(status_code=400, detail="Email already exists")

    user_id = hash_email(payload.email)
    
    if payload.auth_type == "google":
        # For Google OAuth users, we don't need a password
        response = await asyncio.to_thread(
            user_db.create, 
            user_id, 
            email=payload.email, 
            name=payload.first_name + "_" + payload.last_name
        )
        await asyncio.to_thread(user_db.update_status, user_id, True)
        await asyncio.to_thread(user_db.update_email_verification, user_id, True)

        # send_welcome_email(email, name)
        background_tasks.add_task(send_formal_welcome_email, user.email,  payload.first_name)
        
    else:
        # For email users, we need to hash the password
        hashed_password = get_password_hash(payload.password)
        p = dict(
            user_id=user_id,
            email=payload.email,
            password=hashed_password,
            name=payload.first_name + "_" + payload.last_name
        )
        response = await asyncio.to_thread(user_db.create_argon2_user, **p)

    await asyncio.to_thread(user_db.update_labels, user_id, ["unsubscribed"])
    validation_code = generate_random_six_digit_number()
    await asyncio.to_thread(user_db.update_prefs, user_id, 
        {
            "validation_code": validation_code, 
            "theme": "black", 
            "notification": True,
            "timezone": payload.timezone if hasattr(payload, 'timezone') else None
        })
    await UserCredits.get_or_create(user_id)

    if payload.auth_type != "google":
        send_new_user_email(validation_code, payload.email)

    await create_referral_code(user_id)

    if payload.referral_code:
        await Referral.refer_user(user_id, payload.referral_code)


    first_name, last_name = response["name"].rsplit("_", 1)

    user = dict(
        is_new=True,
        user_id=response["$id"],
        email=response["email"],
        first_name=first_name,
        last_name=last_name,
        is_pro=False,
        created_at=response["$createdAt"],
        updated_at=response["$updatedAt"]
    )
    
    access_token = create_access_token(data={"sub": payload.email})
    await system_log("user")
    return  {
        "user": user,
        "token": {"access_token": access_token, "token_type": "bearer"}
    }




async def create_user_profile(
    user: UserIn,
    payload: ProfileSchema, 
    ):
    file_id = None
    if payload.avatar:
        file_id = UserProfile.get_unique_id()
        file = payload.avatar.file
        file.seek(0)
        file = InputFile.from_bytes(
            file.read(),
            payload.avatar.filename,
        )
        await UserProfile.create_file(file_id, file)

    user_profile = await UserProfile.create(
        document_id=user.id,
        data={
            "phone": payload.phone,
            "gender": payload.gender,
            "city": payload.city,
            "country": payload.country,
            "address": payload.address,
            "avatar": file_id
        }
    )
    user_preferences = await UserPreferences.create(
        document_id=user.id,
        data={
            "interest": payload.interests,
            "price_range": payload.price_range,
            "shopping_frequency": payload.shopping_frequency,
            "notification_preferences": payload.notification_preferences,
        }
    )

    # Prepare user data for welcome email
    user_data = {
        "first_name": user.name.split('_')[0],
        "phone": payload.phone,
        "city": payload.city,
        "country": payload.country
    }
    
    # Send formal welcome email using Celery
    # from .email import send_formal_welcome_email
    

    return {
            "user": user,
            "profile": user_profile.to_dict(),
            "preference": user_preferences.to_dict()
        }


async def create_referral_code(user_id: str):
    """
    Create a new referral code for a user.
    Returns the created referral object.
    """
    try:
        # Generate a unique referral code
        code = f"REF{user_id[:6]}{generate_random_six_digit_number()}"
        
        # Create and return the referral
        referral = await Referral.create_referral(user_id, code)
        return referral
        
    except Exception as e:
        logger.error(f"Error creating referral code: {str(e)}")
        raise HTTPException(500, "Failed to create referral code")




    

